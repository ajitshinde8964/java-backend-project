package com.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MovieRepository;

import com.Model.MovieModel;

@Service
public class MovieService {
	@Autowired
	MovieRepository movierepository;

	public void savemv(MovieModel movie) {
		movierepository.save(movie);
	
	}
	public MovieModel findbymovie(String movieName) {
		return movierepository.findbymovie(movieName);
	
	}

	public List<MovieModel> findAllmovie() {
		return movierepository.findAll();
}
	public Optional<MovieModel> findbyid(Long id) {
		return movierepository.findById(id);
	}
	public void deleteallmovies() {
		movierepository.deleteAll();
	}
	public void deletespecificmovie(Long ids) {
		movierepository.deleteById(ids);
	}
	
}
