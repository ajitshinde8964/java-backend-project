package com.Model;

import java.util.Date;

import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.TemporalType;
import lombok.Data;

@Data
@Entity
public class MovieModel {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String movieName;
	private String actor;
	private String actress;
	private int collection_in_cr;


	@jakarta.persistence.Temporal(TemporalType.DATE)
	@LastModifiedDate
	@DateTimeFormat(pattern = "yyyy-MM-dd")

	private Date date_of_realease = new Date();
}
