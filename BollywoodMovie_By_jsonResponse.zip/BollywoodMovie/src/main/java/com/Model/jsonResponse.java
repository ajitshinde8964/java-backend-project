package com.Model;

import lombok.Data;

@Data
public class jsonResponse {

	private String status;
	private String message;
	private String result;
}
