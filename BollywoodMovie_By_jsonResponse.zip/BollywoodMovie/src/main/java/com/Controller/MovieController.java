package com.Controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.Model.MovieModel;
import com.Model.jsonResponse;
import com.Service.MovieService;

@RestController
@RequestMapping("movie")
public class MovieController {

	@Autowired
	MovieService movieservice;

	@PostMapping("/savemovie")
	public jsonResponse saveadmin(@RequestBody MovieModel movie) {

		jsonResponse response = new jsonResponse();

		MovieModel movi = movieservice.findbymovie(movie.getMovieName());
		

		if (movi == null) {
			movieservice.savemv(movie);
			response.setStatus("200");
			response.setResult("success");
			response.setMessage("created succeessfuly");
			return response;
		} else {
			response.setStatus("400");
			response.setResult("unsucessfull");
			response.setMessage("movie allready seen");
		}
		return response;

	}

	@GetMapping("/getall")
	
	public List<MovieModel> getallmovie() {
	List<MovieModel> allmovie = movieservice.findAllmovie();
		return allmovie;	
}
	@GetMapping("get/{id}")
	public jsonResponse moviebyid(@PathVariable Long id) {
		
		jsonResponse response = new jsonResponse();

		Optional<MovieModel> ids = movieservice.findbyid(id);

		if (ids.isPresent()) {
			response.setMessage(ids.get().toString());
			response.setResult("sucesss");
			response.setStatus("200");
		} else {
			response.setStatus("404");
			response.setResult("unsuccessful");
			response.setMessage("this id is not preset in the system");
		}

		return response;
	}
	@DeleteMapping("deleteallmovies")
	public jsonResponse deletemovie() {
		jsonResponse response = new jsonResponse();

		try {
			movieservice.deleteallmovies();
			response.setStatus("200");
			response.setMessage("allmovie are deleted sucessfully");
			response.setResult("success");

		} catch (Exception e) {

			response.setStatus("403");
			response.setMessage("Failed To delete all movie records");
			response.setResult("unsuccess");

		}

		return response;
	}
	@DeleteMapping("/delete/{id}")
	public jsonResponse deletspecifmovie(@PathVariable Long id) {
		
		jsonResponse response = new jsonResponse();
		Optional<MovieModel> admin = movieservice.findbyid(id);

		if (admin.isPresent()) {
			movieservice.deletespecificmovie(id);
			response.setStatus("200");
			response.setMessage("movie deleted successfully");
			response.setResult("success");
		} else {
			response.setStatus("300");
			response.setMessage("movie with this id  allready deleted ");
			response.setResult("unsuccess");
		}
		return response;
		
	}
	// update
		@PostMapping("/update/{ids}")
		public jsonResponse updatemovie(@RequestBody MovieModel movie, @PathVariable Long ids) {
			jsonResponse response = new jsonResponse();

			Optional<MovieModel> movies = movieservice.findbyid(ids);

			if (movies.isPresent()) {
				MovieModel update = movies.get();

				
				update.setActor(movie.getActor());
				update.setActress(movie.getActress());
				update.setCollection_in_cr(movie.getCollection_in_cr());
				update.setDate_of_realease(movie.getDate_of_realease());
				update.setMovieName(movie.getMovieName());

				
				movieservice.savemv(update) ;

				response.setStatus("200");
				response.setMessage("movie updated successfully");
				response.setResult("success");
			} else {
				response.setStatus("404");
				response.setResult("unsuccessful");
				response.setMessage("This id is not present in the system");
			}
			return response;
		}
	
}
